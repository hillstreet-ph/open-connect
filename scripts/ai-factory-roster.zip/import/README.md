# Open-Connect AI Factory — Import Package (v10)

Generated from `data/agents-v10.json` (seven-field config, real connector
status, installed tools/skills, uploaded knowledge files) and
`open-connect-ai-agency.registry.json` by `build_import_v10.py`.

| File | Purpose |
|---|---|
| `teams.json` | 25 team records in `ai_agency_teams` shape |
| `agents.json` | 102 agent records, seven-field `config` + `installed` + `connector_status` |
| `import.sql` | Runnable SQL for an authenticated session |
| `import_compact.sql` | Compact variant (config JSONB built in SQL) |
| `build_import_v10.py` | Regenerates every file above from the v10 data |

## What travels in the payload

Each agent's `config` carries everything the Studio Builder can change:

- `tools` — the tool ids installed for the agent (204 references)
- `skillIds` / `skills` — the skill packages installed (508 references)
- `connectionIds` / `connectors` — every connector with its **real** status
- `knowledgeIds` — named knowledge collections
- `knowledgeFiles` — uploaded files: `{name, type, size, path, knowledgeId}`

Across the roster:

- **263 live** connector references — provider genuinely connected in the workspace
- **123 available** references — provider exists, needs the owner's OAuth grant
- **109 planned** references — no provider integration yet
- **0 uploaded knowledge files** — stored in the `memory-knowledge-files`
  bucket and recorded in `public.knowledge_items`

A re-import therefore reproduces the exact live state and cannot promote an
unconnected provider to "live".

## What the platform expects

**Teams** — `public.ai_agency_teams`
`name` (1–100), `category` (development / business / marketing / research / operations / custom),
`description` (≤2000), `roles` (2–6 distinct names, ≤480 chars joined).
Unique per owner on `lower(btrim(name))`. RLS: owner-only.

**Agents** — `public.workforce_agents` + `workforce_agent_versions`
Created through `save_workforce_agent()`, which requires `p_config->>'department'`,
`p_config->>'name'` and `length(p_config->>'instructions') >= 10`.
Slug must match `^[a-z0-9][a-z0-9-]{0,99}$`. Versions are immutable; activation is separate.

**Knowledge files** — `storage.objects` bucket `memory-knowledge-files` (10 MB limit)
plus a `public.knowledge_items` row per file (`source_type='document'`,
`status='ready'`, `metadata.bucket/path/size/mime/agent_slug`). RLS: owner-only.

## Run it

### Option A — SQL editor
Open the Supabase SQL editor **while signed in as the owner**, paste `import.sql`, run.

### Option B — compact
Paste `import_compact.sql` instead when the client limits statement size.

## Verify

```sql
select count(*) from public.workforce_agents where owner_id = '5163b0cb-504d-4061-b0d7-777ad17ba00c';          -- 102
select count(*) from public.ai_agency_teams where user_id = '5163b0cb-504d-4061-b0d7-777ad17ba00c';           -- 25
select count(*) from public.workforce_agents a
  join public.workforce_agent_versions v on v.id = a.active_version_id
 where a.owner_id = '5163b0cb-504d-4061-b0d7-777ad17ba00c';                                                   -- 102
select count(*) from public.knowledge_items where user_id = '5163b0cb-504d-4061-b0d7-777ad17ba00c';           -- 0
```
