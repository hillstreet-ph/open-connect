/* Open-Connect AI Factory — agent profile drawer (v8, seven-field schema) */
(function () {
  "use strict";

  var DATA_URL = "data/agents-v10.json";
  var cache = null;
  var loading = null;

  var scrim, drawer, bodyEl, headEl;

  function esc(s) {
    return String(s == null ? "" : s)
      .replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;");
  }

  function humanSize(n) {
    return fmtSize(n);
  }

  function fileKind(type, name) {
    var t = String(type || "").toLowerCase();
    var ext = String(name || "").split(".").pop().toLowerCase();
    if (t.indexOf("image") === 0 || /^(png|jpe?g|gif|webp|svg|bmp|avif)$/.test(ext)) return "IMG";
    if (t.indexOf("video") === 0 || /^(mp4|mov|webm|avi|mkv)$/.test(ext)) return "VID";
    if (t.indexOf("audio") === 0 || /^(mp3|wav|ogg|m4a|flac)$/.test(ext)) return "AUD";
    if (t.indexOf("pdf") !== -1 || ext === "pdf") return "PDF";
    if (/^(zip|rar|7z|tar|gz)$/.test(ext)) return "ZIP";
    if (/^(docx?|rtf|odt)$/.test(ext)) return "DOC";
    if (/^(xlsx?|csv|ods)$/.test(ext)) return "XLS";
    if (/^(pptx?|odp)$/.test(ext)) return "PPT";
    if (/^(txt|md|json|ya?ml|xml|html?)$/.test(ext)) return "TXT";
    return "FILE";
  }

  function fmtSize(n) {
    if (n == null || n === "") return "—";
    n = Number(n);
    if (!isFinite(n)) return "—";
    if (n < 1024) return n + " B";
    if (n < 1048576) return (n / 1024).toFixed(1) + " KB";
    return (n / 1048576).toFixed(1) + " MB";
  }

  function build() {
    if (drawer) return;
    scrim = document.createElement("div");
    scrim.className = "pf-scrim";
    scrim.setAttribute("aria-hidden", "true");

    drawer = document.createElement("aside");
    drawer.className = "pf-drawer";
    drawer.setAttribute("role", "dialog");
    drawer.setAttribute("aria-modal", "true");
    drawer.setAttribute("aria-label", "Agent profile");
    drawer.innerHTML =
      '<div class="pf-head" id="pfHead"></div>' +
      '<div class="pf-body" id="pfBody"></div>';

    document.body.appendChild(scrim);
    document.body.appendChild(drawer);
    headEl = drawer.querySelector("#pfHead");
    bodyEl = drawer.querySelector("#pfBody");

    scrim.addEventListener("click", close);
    document.addEventListener("keydown", function (e) {
      if (e.key === "Escape" && drawer.classList.contains("open")) close();
    });
  }

  function load() {
    if (cache) return Promise.resolve(cache);
    if (loading) return loading;
    loading = fetch(DATA_URL, { cache: "force-cache" })
      .then(function (r) {
        if (!r.ok) throw new Error("HTTP " + r.status);
        return r.json();
      })
      .then(function (j) { cache = j; return j; })
      .catch(function (err) {
        loading = null;
        throw err;
      });
    return loading;
  }

  function chip(text, cls) {
    return '<span class="pf-chip' + (cls ? " " + cls : "") + '">' + esc(text) + "</span>";
  }

  function renderHead(p, slug) {
    var live = (p.connectors || []).filter(function (c) { return c.status === "live"; }).length;
    headEl.innerHTML =
      '<div class="pf-headmain">' +
        '<span class="pf-eyebrow">Agent profile</span>' +
        '<h3 class="pf-name">' + esc(p.name) + "</h3>" +
        '<div class="pf-role">' + esc(slug) + "</div>" +
        '<div class="pf-chips">' +
          chip("7 fields") +
          chip((p.skills || []).length + " skills") +
          chip((p.tools || []).length + " tools") +
          chip(live + " live connectors") +
        "</div>" +
      "</div>" +
      '<button class="pf-close" type="button" aria-label="Close profile">' +
        '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M6 6l12 12M18 6L6 18"/></svg>' +
      "</button>";
    var btn = headEl.querySelector(".pf-close");
    if (btn) btn.addEventListener("click", close);
  }

  function render(p, slug) {
    renderHead(p, slug);

    var h = "";

    h += '<div class="pf-sec"><h5>1 &middot; Name</h5>' +
         '<p class="pf-desc">' + esc(p.name) + "</p></div>";

    h += '<div class="pf-sec"><h5>2 &middot; Description</h5>' +
         '<p class="pf-desc">' + esc(p.description) + "</p></div>";

    h += '<div class="pf-sec"><h5>3 &middot; Instruction</h5>' +
         '<div class="pf-instruction">' + esc(p.instruction) + "</div></div>";

    var kn = p.knowledge || [];
    var kf = p.knowledgeFiles || [];
    h += '<div class="pf-sec"><h5>4 &middot; Knowledge <span class="n">' + (kn.length + kf.length) + "</span></h5>";
    if (kn.length) {
      h += '<div class="pf-list">';
      kn.forEach(function (k) { h += '<span class="pf-item">' + esc(k) + "</span>"; });
      h += "</div>";
    }
    if (kf.length) {
      h += '<div class="pf-files">';
      kf.forEach(function (f) {
        h += '<div class="pf-filerow">' +
             '<span class="pf-ftype">' + esc(fileKind(f.type, f.name)) + "</span>" +
             '<span class="pf-fname" title="' + esc(f.storagePath || "") + '">' + esc(f.name) + "</span>" +
             '<span class="pf-fsize">' + esc(humanSize(f.size)) + "</span></div>";
      });
      h += "</div>";
    }
    if (!kn.length && !kf.length) {
      h += '<p class="pf-note">No knowledge collections or files attached yet.</p>';
    }
    h += "</div>";

    var tl = p.tools || [];
    h += '<div class="pf-sec"><h5>5 &middot; Tools <span class="n">' + tl.length + "</span></h5>";
    if (tl.length) {
      h += '<div class="pf-list">';
      tl.forEach(function (t) {
        h += '<span class="pf-item skill" title="' + esc(t.description || "") + '">' + esc(t.label) + "</span>";
      });
      h += "</div>";
    } else {
      h += '<p class="pf-note">No tools granted.</p>';
    }
    h += "</div>";

    var sk = p.skills || [];
    h += '<div class="pf-sec"><h5>6 &middot; Skills <span class="n">' + sk.length + "</span></h5>";
    if (sk.length) {
      h += '<div class="pf-list">';
      sk.forEach(function (s) { h += '<span class="pf-item skill">' + esc(s.label) + "</span>"; });
      h += "</div>";
    } else {
      h += '<p class="pf-note">No skills installed.</p>';
    }
    h += "</div>";

    var cn = p.connectors || [];
    var live = cn.filter(function (c) { return c.status === "live"; }).length;
    h += '<div class="pf-sec"><h5>7 &middot; Connectors <span class="n">' + live + "/" + cn.length + " live</span></h5>";
    if (cn.length) {
      h += '<div class="pf-conn">';
      cn.forEach(function (c) {
        var st = c.status === "live" ? "live" : (c.status === "available" ? "available" : "planned");
        h += '<div class="pf-connrow ' + st + '">' +
             '<span class="dot"></span><span class="lbl">' + esc(c.label) + "</span>" +
             '<span class="st">' + st + "</span></div>";
      });
      h += "</div>";
      if (live < cn.length) {
        h += '<p class="pf-note" style="margin-top:10px">Only <strong>live</strong> means the provider is genuinely connected in this workspace, verified against <code>app_connections</code>. <strong>Available</strong> has a real provider integration the owner can connect with their own authorization; <strong>planned</strong> has no provider integration yet. The agent will not claim to have used any of them until they are live.</p>';
      }
    } else {
      h += '<p class="pf-note">No connectors requested.</p>';
    }
    h += "</div>";

    bodyEl.innerHTML = h;
    bodyEl.scrollTop = 0;
  }

  function open(slug) {
    build();
    document.body.classList.add("pf-lock");
    scrim.classList.add("open");
    drawer.classList.add("open");
    headEl.innerHTML = '<div class="pf-headmain"><span class="pf-eyebrow">Loading</span><h3 class="pf-name">' + esc(slug) + "</h3></div>";
    bodyEl.innerHTML = '<p class="pf-desc">Loading profile&hellip;</p>';

    load().then(function (data) {
      var p = data[slug];
      if (!p) {
        bodyEl.innerHTML = '<p class="pf-desc">No profile found for <code>' + esc(slug) + "</code>.</p>";
        return;
      }
      render(p, slug);
    }).catch(function () {
      bodyEl.innerHTML = '<p class="pf-desc">Could not load the profile data. Open this page over http:// rather than from disk.</p>';
    });
  }

  function close() {
    if (!drawer) return;
    drawer.classList.remove("open");
    scrim.classList.remove("open");
    document.body.classList.remove("pf-lock");
  }

  function slugOf(card) {
    if (card.dataset.slug) return card.dataset.slug;
    var idEl = card.querySelector(".agent-id");
    return idEl ? idEl.textContent.trim() : null;
  }

  function wire() {
    var cards = document.querySelectorAll(".agent-card");
    Array.prototype.forEach.call(cards, function (card) {
      var slug = slugOf(card);
      if (!slug) return;
      card.dataset.slug = slug;
      card.setAttribute("tabindex", "0");
      card.setAttribute("role", "button");
      card.setAttribute("aria-label", "Open profile for " + slug);

      if (!card.querySelector(".agent-open")) {
        var b = document.createElement("span");
        b.className = "agent-open";
        b.innerHTML = "View profile" +
          '<svg viewBox="0 0 24 24" width="11" height="11" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M5 12h14M13 6l6 6-6 6"/></svg>';
        var foot = card.querySelector(".agent-foot");
        if (foot && foot.parentNode) foot.parentNode.insertBefore(b, foot);
        else card.querySelector(".agent-body").appendChild(b);
      }

      card.addEventListener("click", function (e) {
        if (e.target.closest("a")) return;
        open(slug);
      });
      card.addEventListener("keydown", function (e) {
        if (e.key === "Enter" || e.key === " ") {
          e.preventDefault();
          open(slug);
        }
      });
    });
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", wire);
  } else {
    wire();
  }

  window.AgentProfile = { open: open, close: close };
})();
