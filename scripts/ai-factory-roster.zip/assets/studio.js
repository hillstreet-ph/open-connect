/* Open-Connect AI Factory — Studio builder (v10)
   Install / add experience for tools, skills and connectors, plus knowledge
   and file upload. Writes real versions to production Supabase via the
   save_workforce_agent RPC (authenticated session required by RLS).

   Honesty rule: a connector is only ever shown as "live" when its provider
   has app_connections.status = 'connected' for the signed-in owner. Anything
   else is "available" (real provider, owner must authorize) or "planned"
   (no provider integration). The toggle cannot claim a connection that does
   not exist — the badge is derived from the database, never from the draft. */
(function () {
  "use strict";

  var SUPABASE_URL = "https://huadtiuuoiriqrjpjxhr.supabase.co";
  var SUPABASE_ANON = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Imh1YWR0aXV1b2lyaXFyanBqeGhyIiwicm9sZSI6ImFub24iLCJpYXQiOjE3ODk1MzIwODMsImV4cCI6MjEwNTEwODA4M30.5TF6RWJ7ycwI2YJqu_aYVS7ZZxXAIGSCcim3ilkPr0w";
  var CATALOG_URL = "data/catalog-v11.json";
  var BUCKET = "memory-knowledge-files";
  var MAX_BYTES = 10 * 1024 * 1024;   // bucket limit

  // knowledge_items check constraints (verified against production)
  var SRC_TYPE = "document";          // allowed: url | note | document | api
  var SRC_STATUS = "ready";           // allowed: ready | archived

  // resources.category_slug is a FK to public.categories — only these exist
  var CATEGORIES = ["ai", "browser", "business", "communication", "connections",
    "data", "developer", "development", "infrastructure", "knowledge",
    "productivity", "security"];

  var sb = null;
  var user = null;
  var cat = { tools: [], skills: [], connectors: [], liveProviders: [], pendingProviders: [] };
  var liveSet = {};                   // provider -> true when genuinely connected
  var roster = [];
  var current = null;
  var draft = blankDraft();
  var dirty = false;
  var uploading = 0;

  var $ = function (id) { return document.getElementById(id); };

  function blankDraft() {
    return {
      name: "", description: "", instruction: "",
      knowledge: [], files: [], tools: [], skills: [], connectors: [],
      department: "", slug: "", driver: "bot-driven"
    };
  }

  function esc(s) {
    return String(s == null ? "" : s)
      .replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
  }

  function msg(el, text, kind) {
    el.textContent = text || "";
    el.className = "st-msg" + (kind ? " " + kind : "");
  }

  function setSave(text, kind) {
    var el = $("saveState");
    el.textContent = text || "";
    el.className = "st-save" + (kind ? " " + kind : "");
  }

  function fmtSize(n) {
    if (n == null) return "";
    if (n < 1024) return n + " B";
    if (n < 1048576) return (n / 1024).toFixed(1) + " KB";
    return (n / 1048576).toFixed(1) + " MB";
  }

  function extOf(name) {
    var m = /\.([a-z0-9]+)$/i.exec(name || "");
    return m ? m[1].toLowerCase() : "file";
  }

  function kindOf(name, mime) {
    var e = extOf(name);
    var m = (mime || "").toLowerCase();
    if (m.indexOf("image/") === 0 || ["png", "jpg", "jpeg", "webp", "gif", "svg"].indexOf(e) !== -1) return "img";
    if (m.indexOf("video/") === 0 || ["mp4", "mov", "webm", "avi", "mkv"].indexOf(e) !== -1) return "vid";
    if (m.indexOf("audio/") === 0 || ["mp3", "wav", "m4a", "ogg", "flac"].indexOf(e) !== -1) return "aud";
    if (["zip", "rar", "7z", "tar", "gz"].indexOf(e) !== -1) return "zip";
    return "doc";
  }

  function slugify(s) {
    return String(s || "").toLowerCase().trim()
      .replace(/[^a-z0-9]+/g, "-").replace(/^-+|-+$/g, "").slice(0, 60);
  }

  /* ------------------------------------------------------------------ */
  /* boot                                                                */
  /* ------------------------------------------------------------------ */
  function boot() {
    if (!window.supabase || !window.supabase.createClient) {
      msg($("gateMsg"), "Could not load the Supabase client. Check the network and reload.", "err");
      return;
    }
    sb = window.supabase.createClient(SUPABASE_URL, SUPABASE_ANON, {
      auth: { persistSession: true, autoRefreshToken: true }
    });

    loadCatalog();

    sb.auth.getSession().then(function (res) {
      var s = res && res.data && res.data.session;
      if (s) enter(s.user); else showGate();
    });

    sb.auth.onAuthStateChange(function (_evt, session) {
      if (session) enter(session.user); else showGate();
    });

    $("signinForm").addEventListener("submit", onSignIn);
    $("signoutBtn").addEventListener("click", function () { sb.auth.signOut(); });
    $("newBtn").addEventListener("click", newAgent);
    $("resetBtn").addEventListener("click", function () { if (current) selectAgent(current); else newAgent(); });
    $("agentForm").addEventListener("submit", onSave);
    $("previewBtn").addEventListener("click", openCardPreview);
    $("rosterSearch").addEventListener("input", renderRoster);

    $("knowAdd").addEventListener("click", addKnowledge);
    $("fKnow").addEventListener("keydown", function (e) {
      if (e.key === "Enter") { e.preventDefault(); addKnowledge(); }
    });

    $("toolSearch").addEventListener("input", renderToolPicker);
    $("skillSearch").addEventListener("input", renderSkillPicker);
    $("connSearch").addEventListener("input", renderConnPicker);

    // file upload
    $("dropZone").addEventListener("click", function () { $("fileInput").click(); });
    $("dropZone").addEventListener("keydown", function (e) {
      if (e.key === "Enter" || e.key === " ") { e.preventDefault(); $("fileInput").click(); }
    });
    $("fileInput").addEventListener("change", function () {
      handleFiles($("fileInput").files);
      $("fileInput").value = "";
    });
    ["dragenter", "dragover"].forEach(function (ev) {
      $("dropZone").addEventListener(ev, function (e) {
        e.preventDefault(); $("dropZone").classList.add("over");
      });
    });
    ["dragleave", "drop"].forEach(function (ev) {
      $("dropZone").addEventListener(ev, function (e) {
        e.preventDefault(); $("dropZone").classList.remove("over");
      });
    });
    $("dropZone").addEventListener("drop", function (e) {
      if (e.dataTransfer && e.dataTransfer.files) handleFiles(e.dataTransfer.files);
    });

    // create-new modal
    Array.prototype.forEach.call(document.querySelectorAll("[data-create]"), function (b) {
      b.addEventListener("click", function () { openCreate(b.getAttribute("data-create")); });
    });
    $("createForm").addEventListener("submit", onCreateSubmit);
    Array.prototype.forEach.call(document.querySelectorAll("[data-close]"), function (b) {
      b.addEventListener("click", closeModals);
    });
    document.addEventListener("keydown", function (e) {
      if (e.key === "Escape") closeModals();
    });

    ["fName", "fDesc", "fInstr", "fDept", "fSlug"].forEach(function (id) {
      $(id).addEventListener("input", function () {
        draft[fieldOf(id)] = $(id).value;
        dirty = true;
        if (id === "fName") {
          $("edTitle").textContent = $(id).value || "Untitled agent";
          if (!current) $("fSlug").value = slugify($(id).value);
        }
      });
    });
    $("fDriver").addEventListener("change", function () { draft.driver = $("fDriver").value; dirty = true; });
  }

  function fieldOf(id) {
    return { fName: "name", fDesc: "description", fInstr: "instruction", fDept: "department", fSlug: "slug" }[id];
  }

  /* ------------------------------------------------------------------ */
  /* catalog                                                             */
  /* ------------------------------------------------------------------ */
  function loadCatalog() {
    fetch(CATALOG_URL, { cache: "force-cache" })
      .then(function (r) { if (!r.ok) throw new Error("HTTP " + r.status); return r.json(); })
      .then(function (j) {
        cat = j || cat;
        cat.tools = cat.tools || [];
        cat.skills = cat.skills || [];
        cat.connectors = cat.connectors || [];
        liveSet = {};
        (cat.liveProviders || []).forEach(function (p) { liveSet[p] = true; });
        paintCatalogBar("snapshot");
        if (user) { renderToolPicker(); renderSkillPicker(); renderConnPicker(); }
      })
      .catch(function () {
        $("catSrc").textContent = "catalog unavailable — check the network";
        $("catSrc").className = "st-catsrc";
      });
  }

  function paintCatalogBar(mode) {
    $("catTools").innerHTML = "<b>" + cat.tools.length + "</b> tools";
    $("catSkills").innerHTML = "<b>" + cat.skills.length + "</b> skills";
    $("catConns").innerHTML = "<b>" + cat.connectors.length + "</b> connectors";
    $("catLive").innerHTML = "<b>" + (cat.liveProviders || []).length + "</b> live providers";
    var el = $("catSrc");
    if (mode === "live") {
      el.textContent = "live from public.resources · " + (cat.generatedAt || "");
      el.className = "st-catsrc live";
    } else {
      el.textContent = "snapshot " + (cat.generatedAt || "") + " · re-read live on sign-in";
      el.className = "st-catsrc snap";
    }
  }

  /* Re-read the catalog and the owner's connections straight from the
     database once we have a session, so the picker shows current options
     rather than only the bundled snapshot. */
  function refreshLive() {
    var jobs = [];

    jobs.push(sb.from("resources")
      .select("slug,name,description,resource_type,category_slug,installation_type,verified,featured,owner_id")
      .eq("published", true).order("name").limit(2000)
      .then(function (res) {
        if (res.error || !res.data) return;
        var tools = [], skills = [], seenT = {}, seenS = {};
        res.data.forEach(function (r) {
          var rt = r.resource_type, slug = r.slug, name = (r.name || slug || "").trim();
          if (!slug || !name) return;
          var item = {
            id: slug, label: name,
            description: (r.description || "").trim(),
            kind: rt, category: r.category_slug || "",
            install: r.installation_type || "",
            verified: !!r.verified, featured: !!r.featured,
            owner: r.owner_id ? "workspace" : "catalog"
          };
          if (rt === "tool" || rt === "mcp" || rt === "app" || rt === "toolkit") {
            if (!seenT[slug]) { seenT[slug] = 1; tools.push(item); }
          } else if (rt === "skill" || rt === "plugin") {
            if (!seenS[slug]) { seenS[slug] = 1; skills.push(item); }
          }
        });
        if (tools.length) cat.tools = tools;
        if (skills.length) cat.skills = skills;
      }));

    jobs.push(sb.from("app_connections").select("provider,status").limit(2000)
      .then(function (res) {
        if (res.error || !res.data) return;
        var live = {}, pend = {};
        res.data.forEach(function (c) {
          if (c.status === "connected") live[c.provider] = 1;
          else if (c.status === "pending" || c.status === "configured_unverified") pend[c.provider] = 1;
        });
        cat.liveProviders = Object.keys(live).sort();
        cat.pendingProviders = Object.keys(pend).sort();
        liveSet = live;
      }));

    return Promise.all(jobs).then(function () {
      paintCatalogBar("live");
      renderToolPicker(); renderSkillPicker(); renderConnPicker();
    }).catch(function () { /* snapshot stays in place */ });
  }

  /* ------------------------------------------------------------------ */
  /* auth                                                                */
  /* ------------------------------------------------------------------ */
  function showGate() {
    user = null;
    $("gateSec").style.display = "";
    $("builderSec").style.display = "none";
  }

  function enter(u) {
    user = u;
    $("gateSec").style.display = "none";
    $("builderSec").style.display = "";
    $("whoEmail").textContent = u.email || u.id;
    loadRoster();
    refreshLive();
  }

  function onSignIn(e) {
    e.preventDefault();
    var btn = $("signinBtn");
    btn.disabled = true;
    msg($("gateMsg"), "Signing in…");
    sb.auth.signInWithPassword({
      email: $("email").value.trim(),
      password: $("password").value
    }).then(function (res) {
      btn.disabled = false;
      if (res.error) { msg($("gateMsg"), res.error.message, "err"); return; }
      msg($("gateMsg"), "");
      $("password").value = "";
    }).catch(function (err) {
      btn.disabled = false;
      msg($("gateMsg"), err.message || "Sign-in failed.", "err");
    });
  }

  /* ------------------------------------------------------------------ */
  /* roster                                                              */
  /* ------------------------------------------------------------------ */
  function loadRoster() {
    setSave("Loading roster…");
    sb.from("workforce_agents")
      .select("id,slug,department,lead,active_version_id,enabled")
      .order("slug")
      .then(function (res) {
        if (res.error) { setSave("Roster error: " + res.error.message, "err"); return; }
        var agents = res.data || [];
        var ids = agents.map(function (a) { return a.active_version_id; }).filter(Boolean);
        if (!ids.length) { roster = agents; renderRoster(); setSave(""); return; }
        return sb.from("workforce_agent_versions")
          .select("id,agent_id,number,config")
          .in("id", ids)
          .then(function (vres) {
            var byId = {};
            (vres.data || []).forEach(function (v) { byId[v.id] = v; });
            roster = agents.map(function (a) {
              var v = byId[a.active_version_id] || {};
              return {
                id: a.id, slug: a.slug, department: a.department, lead: a.lead,
                enabled: a.enabled, active_version_id: a.active_version_id,
                number: v.number || 0, config: v.config || {}
              };
            });
            renderRoster();
            setSave(roster.length + " agents loaded");
            setTimeout(function () { setSave(""); }, 2500);
          });
      })
      .catch(function (err) { setSave("Roster error: " + (err.message || err), "err"); });
  }

  function renderRoster() {
    var q = ($("rosterSearch").value || "").trim().toLowerCase();
    var list = roster.filter(function (a) {
      if (!q) return true;
      var n = (a.config.name || "").toLowerCase();
      return a.slug.indexOf(q) !== -1 || n.indexOf(q) !== -1 || (a.department || "").indexOf(q) !== -1;
    });
    $("rosterCount").textContent = list.length;
    var h = "";
    list.forEach(function (a) {
      var on = current && current.id === a.id ? " on" : "";
      h += '<button type="button" class="st-rrow' + on + '" data-id="' + esc(a.id) + '" role="option" aria-selected="' + (on ? "true" : "false") + '">' +
           esc(a.config.name || a.slug) +
           '<span class="sl">' + esc(a.slug) + " · v" + a.number + "</span></button>";
    });
    if (!list.length) h = '<p class="st-help" style="padding:8px 10px">No agents match.</p>';
    $("roster").innerHTML = h;
    Array.prototype.forEach.call($("roster").querySelectorAll(".st-rrow"), function (b) {
      b.addEventListener("click", function () {
        var id = b.getAttribute("data-id");
        var row = roster.filter(function (r) { return r.id === id; })[0];
        if (row) selectAgent(row);
      });
    });
  }

  function selectAgent(row) {
    current = row;
    var c = row.config || {};
    draft = {
      name: c.name || "",
      description: c.description || "",
      instruction: c.instructions || c.instruction || "",
      knowledge: (c.knowledge || []).slice(),
      files: (c.knowledgeFiles || []).slice(),
      tools: (c.tools || []).map(function (t) { return typeof t === "string" ? t : t.id; }),
      skills: (c.skillIds || c.skills || []).map(function (s) { return typeof s === "string" ? s : s.id; }),
      connectors: (c.connectionIds || c.connectors || []).map(function (x) { return typeof x === "string" ? x : x.id; }),
      department: c.department || row.department || "",
      slug: row.slug,
      driver: c.driver || (row.lead ? "human-led" : "bot-driven")
    };
    $("edMode").textContent = "Editing · version " + row.number;
    $("edTitle").textContent = draft.name || row.slug;
    $("fSlug").readOnly = true;
    paint();
    renderRoster();
    dirty = false;
    msg($("formMsg"), "");
  }

  function newAgent() {
    current = null;
    draft = blankDraft();
    $("edMode").textContent = "New agent";
    $("edTitle").textContent = "Untitled agent";
    $("fSlug").readOnly = false;
    paint();
    renderRoster();
    dirty = false;
    msg($("formMsg"), "");
    $("fName").focus();
  }

  /* ------------------------------------------------------------------ */
  /* paint                                                               */
  /* ------------------------------------------------------------------ */
  function paint() {
    $("fName").value = draft.name;
    $("fDesc").value = draft.description;
    $("fInstr").value = draft.instruction;
    $("fDept").value = draft.department;
    $("fSlug").value = draft.slug;
    $("fDriver").value = draft.driver;
    renderKnowledge();
    renderFiles();
    renderToolPicker();
    renderSkillPicker();
    renderConnPicker();
  }

  function renderKnowledge() {
    $("knowCount").textContent = draft.knowledge.length;
    var h = "";
    draft.knowledge.forEach(function (k, i) {
      h += '<span class="st-tag"><span>' + esc(k) + '</span><button type="button" data-i="' + i + '" aria-label="Remove ' + esc(k) + '">&times;</button></span>';
    });
    $("knowTags").innerHTML = h;
    Array.prototype.forEach.call($("knowTags").querySelectorAll("button"), function (b) {
      b.addEventListener("click", function () {
        draft.knowledge.splice(parseInt(b.getAttribute("data-i"), 10), 1);
        dirty = true;
        renderKnowledge();
      });
    });
  }

  function addKnowledge() {
    var v = ($("fKnow").value || "").trim();
    if (!v) return;
    if (draft.knowledge.indexOf(v) === -1) draft.knowledge.push(v);
    $("fKnow").value = "";
    dirty = true;
    renderKnowledge();
  }

  /* ---- uploaded files ---- */
  function renderFiles() {
    var h = "";
    draft.files.forEach(function (f, i) {
      var k = kindOf(f.name, f.mime);
      var st = f.status === "uploaded" ? "up" : (f.status === "error" ? "err" : "pend");
      var stTxt = f.status === "uploaded" ? "stored" : (f.status === "error" ? "failed" : "uploading");
      h += '<div class="st-file">' +
             '<span class="ic ' + k + '">' + esc(extOf(f.name).slice(0, 4)) + "</span>" +
             '<span class="meta"><span class="nm">' + esc(f.name) + "</span>" +
             '<span class="sz">' + esc(f.type || extOf(f.name).toUpperCase()) + " · " + fmtSize(f.size) +
             (f.path ? " · " + esc(f.path) : "") + "</span></span>" +
             '<span class="st ' + st + '">' + stTxt + "</span>" +
             '<button type="button" class="rm" data-i="' + i + '" aria-label="Remove ' + esc(f.name) + '">&times;</button>' +
           "</div>";
    });
    $("fileList").innerHTML = h;
    Array.prototype.forEach.call($("fileList").querySelectorAll(".rm"), function (b) {
      b.addEventListener("click", function () {
        var i = parseInt(b.getAttribute("data-i"), 10);
        var f = draft.files[i];
        draft.files.splice(i, 1);
        dirty = true;
        renderFiles();
        if (f && f.path) removeStoredFile(f);
      });
    });
  }

  function handleFiles(list) {
    if (!list || !list.length) return;
    if (!user) { msg($("formMsg"), "Sign in before uploading files.", "err"); return; }
    var slug = ($("fSlug").value || "").trim() || "unassigned";
    Array.prototype.forEach.call(list, function (file) {
      if (file.size > MAX_BYTES) {
        draft.files.push({ name: file.name, size: file.size, type: file.type, status: "error", error: "over 10 MB" });
        renderFiles();
        return;
      }
      var rec = { name: file.name, size: file.size, type: file.type, status: "pending" };
      draft.files.push(rec);
      renderFiles();
      uploadOne(file, slug, rec);
    });
  }

  function uploadOne(file, slug, rec) {
    uploading++;
    setSave("Uploading " + file.name + "…");
    var safe = file.name.replace(/[^A-Za-z0-9._-]/g, "_");
    var path = user.id + "/" + slug + "/" + Date.now() + "-" + safe;

    sb.storage.from(BUCKET).upload(path, file, {
      cacheControl: "3600", upsert: false, contentType: file.type || "application/octet-stream"
    }).then(function (res) {
      if (res.error) throw res.error;
      rec.path = path;
      rec.status = "uploaded";
      // record the reference in knowledge_items so a re-import can see it
      return sb.from("knowledge_items").insert({
        user_id: user.id,
        title: file.name,
        content: "Uploaded knowledge file for agent " + slug + " (" + file.name + ")",
        source_type: SRC_TYPE,
        status: SRC_STATUS,
        mime_type: file.type || null,
        tags: ["studio-upload", slug],
        metadata: {
          bucket: BUCKET, path: path, size: file.size,
          mime: file.type || null, agent_slug: slug, uploaded_via: "studio-v10"
        }
      }).then(function (kres) {
        if (!kres.error && kres.data && kres.data[0]) rec.knowledgeId = kres.data[0].id;
      });
    }).then(function () {
      uploading--;
      dirty = true;
      renderFiles();
      setSave(uploading ? "Uploading…" : "File stored", "ok");
      if (!uploading) setTimeout(function () { setSave(""); }, 2500);
    }).catch(function (err) {
      uploading--;
      rec.status = "error";
      rec.error = (err && err.message) || String(err);
      renderFiles();
      setSave("Upload failed", "err");
      msg($("formMsg"), "Upload failed for " + file.name + ": " + rec.error, "err");
    });
  }

  function removeStoredFile(f) {
    if (f.path) sb.storage.from(BUCKET).remove([f.path]).catch(function () {});
    if (f.knowledgeId) sb.from("knowledge_items").delete().eq("id", f.knowledgeId).catch(function () {});
  }

  /* ---- pickers ---- */
  function pickerItem(id, label, desc, on, badge, disabled) {
    return '<button type="button" class="st-pick' + (on ? " on" : "") + (disabled ? " dis" : "") +
      '" data-id="' + esc(id) + '" aria-pressed="' + (on ? "true" : "false") + '"' +
      (disabled ? ' aria-disabled="true"' : "") + ">" +
      '<span class="box"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3.5" stroke-linecap="round" stroke-linejoin="round"><path d="M4 12.5 9.5 18 20 6.5"/></svg></span>' +
      '<span class="txt"><span class="nm">' + esc(label) + "</span>" +
      (desc ? '<span class="ds">' + esc(desc) + "</span>" : "") +
      "</span>" +
      (badge ? '<span class="badge ' + badge.cls + '">' + badge.text + "</span>" : "") +
      "</button>";
  }

  function wirePicker(el, arr, after) {
    Array.prototype.forEach.call(el.querySelectorAll(".st-pick"), function (b) {
      b.addEventListener("click", function () {
        if (b.getAttribute("aria-disabled") === "true") return;
        var id = b.getAttribute("data-id");
        var i = arr.indexOf(id);
        if (i === -1) arr.push(id); else arr.splice(i, 1);
        dirty = true;
        after();
      });
    });
  }

  function renderToolPicker() {
    $("toolCount").textContent = draft.tools.length;
    var q = ($("toolSearch").value || "").trim().toLowerCase();
    var h = "", shown = 0;
    cat.tools.forEach(function (t) {
      var on = draft.tools.indexOf(t.id) !== -1;
      if (q && !on && t.label.toLowerCase().indexOf(q) === -1 && t.id.indexOf(q) === -1) return;
      shown++;
      var badge = t.owner === "workspace" ? { cls: "new", text: "yours" } : null;
      h += pickerItem(t.id, t.label, t.description || t.id, on, badge, false);
    });
    if (!shown) h = '<p class="st-help">No tools match that filter.</p>';
    $("toolPicker").innerHTML = h;
    wirePicker($("toolPicker"), draft.tools, renderToolPicker);
  }

  function renderSkillPicker() {
    $("skillCount").textContent = draft.skills.length;
    var q = ($("skillSearch").value || "").trim().toLowerCase();
    var h = "", shown = 0;
    cat.skills.forEach(function (s) {
      var on = draft.skills.indexOf(s.id) !== -1;
      if (q && !on && s.label.toLowerCase().indexOf(q) === -1 && s.id.indexOf(q) === -1) return;
      shown++;
      var badge = s.owner === "workspace" ? { cls: "new", text: "yours" } : null;
      h += pickerItem(s.id, s.label, s.description || s.id, on, badge, false);
    });
    if (!shown) h = '<p class="st-help">No skills match that filter.</p>';
    $("skillPicker").innerHTML = h;
    wirePicker($("skillPicker"), draft.skills, renderSkillPicker);
  }

  /* Connector status is derived from the database, never from the draft.
     live      -> provider connected for this owner (toggle enabled)
     available -> real provider integration, owner must authorize (toggle enabled, records intent)
     planned   -> no provider integration yet (toggle enabled, records intent) */
  function connStatus(c) {
    var prov = c.provider || "";
    if (prov && liveSet[prov]) return "live";
    if (prov && (cat.pendingProviders || []).indexOf(prov) !== -1) return "available";
    if (prov) return "available";
    return "planned";
  }

  function renderConnPicker() {
    $("connCount").textContent = draft.connectors.length;
    var q = ($("connSearch").value || "").trim().toLowerCase();
    var h = "", shown = 0;
    cat.connectors.forEach(function (c) {
      var on = draft.connectors.indexOf(c.id) !== -1;
      if (q && !on && c.label.toLowerCase().indexOf(q) === -1 && c.id.indexOf(q) === -1) return;
      shown++;
      var st = connStatus(c);
      var badge = st === "live" ? { cls: "live", text: "live" }
        : (st === "available" ? { cls: "avail", text: "available" } : { cls: "plan", text: "planned" });
      h += pickerItem(c.id, c.label, c.unlocks || c.id, on, badge, false);
    });
    if (!shown) h = '<p class="st-help">No connectors match that filter.</p>';
    $("connPicker").innerHTML = h;
    wirePicker($("connPicker"), draft.connectors, renderConnPicker);
  }

  /* ------------------------------------------------------------------ */
  /* create new item                                                     */
  /* ------------------------------------------------------------------ */
  var createKind = "tool";

  function openCreate(kind) {
    createKind = kind;
    var label = kind === "skill" ? "skill" : (kind === "connector" ? "connector" : "tool");
    $("cmKind").textContent = "New " + label;
    $("cmTitle").textContent = "Create a new " + label;
    $("cmName").value = "";
    $("cmDesc").value = "";
    $("cmMsg").textContent = "";
    $("cmMsg").className = "st-msg";
    var extra = "";
    if (kind === "connector") {
      extra = '<label class="st-lbl" for="cmProvider">Provider slug</label>' +
        '<input class="st-in" id="cmProvider" placeholder="e.g. slack — leave blank if there is no provider yet">' +
        '<p class="st-help">A connector with no provider is recorded as <strong>planned</strong> and can never show as live.</p>';
    } else {
      extra = '<label class="st-lbl" for="cmCategory">Category</label>' +
        '<input class="st-in" id="cmCategory" placeholder="e.g. operations">';
    }
    $("cmExtra").innerHTML = extra;
    $("createModal").hidden = false;
    $("cmName").focus();
  }

  function closeModals() {
    $("createModal").hidden = true;
    $("cardModal").hidden = true;
  }

  function onCreateSubmit(e) {
    e.preventDefault();
    if (!user) { msg($("cmMsg"), "Sign in first.", "err"); return; }
    var name = ($("cmName").value || "").trim();
    var desc = ($("cmDesc").value || "").trim();
    if (!name) { msg($("cmMsg"), "A name is required.", "err"); return; }

    var btn = $("cmSubmit");
    btn.disabled = true;
    msg($("cmMsg"), "Creating…");

    var slug = slugify(name);
    var rtype = createKind === "skill" ? "skill" : (createKind === "connector" ? "app" : "tool");
    var row = {
      slug: slug,
      name: name,
      description: desc || null,
      resource_type: rtype,
      category_slug: ($("cmCategory") ? ($("cmCategory").value || "").trim() : "") || null,
      installation_type: createKind === "connector" ? "oauth" : "native",
      installation_config: createKind === "connector"
        ? { provider: ($("cmProvider") ? ($("cmProvider").value || "").trim() : ""), created_via: "studio-v10" }
        : { created_via: "studio-v10" },
      published: false,
      owner_id: user.id
    };

    sb.from("resources").insert(row).select().then(function (res) {
      btn.disabled = false;
      if (res.error) {
        // slug collision — retry once with a suffix
        if (String(res.error.message || "").indexOf("duplicate") !== -1) {
          row.slug = slug + "-" + Date.now().toString(36).slice(-4);
          return sb.from("resources").insert(row).select().then(function (r2) {
            if (r2.error) { msg($("cmMsg"), r2.error.message, "err"); return; }
            attachCreated(r2.data[0]);
          });
        }
        msg($("cmMsg"), res.error.message, "err");
        return;
      }
      attachCreated(res.data[0]);
    }).catch(function (err) {
      btn.disabled = false;
      msg($("cmMsg"), (err && err.message) || String(err), "err");
    });
  }

  function attachCreated(r) {
    var item = {
      id: r.slug, label: r.name, description: r.description || "",
      kind: r.resource_type, category: r.category_slug || "",
      install: r.installation_type || "", verified: false, featured: false, owner: "workspace"
    };
    if (createKind === "skill") {
      cat.skills.unshift(item);
      if (draft.skills.indexOf(item.id) === -1) draft.skills.push(item.id);
      renderSkillPicker();
    } else if (createKind === "connector") {
      cat.connectors.unshift({
        id: r.slug, label: r.name, provider: (r.installation_config || {}).provider || "",
        unlocks: r.description || "", auth: "oauth", catalogStatus: "planned"
      });
      if (draft.connectors.indexOf(item.id) === -1) draft.connectors.push(item.id);
      renderConnPicker();
    } else {
      cat.tools.unshift(item);
      if (draft.tools.indexOf(item.id) === -1) draft.tools.push(item.id);
      renderToolPicker();
    }
    dirty = true;
    closeModals();
    msg($("formMsg"), "Created “" + r.name + "” and attached it. Save the agent to persist.", "ok");
  }

  /* ------------------------------------------------------------------ */
  /* card preview                                                        */
  /* ------------------------------------------------------------------ */
  function openCardPreview() {
    var name = ($("fName").value || "").trim() || "Untitled agent";
    var slug = ($("fSlug").value || "").trim() || "unassigned";
    var desc = ($("fDesc").value || "").trim();
    var instr = ($("fInstr").value || "").trim();

    var toolMap = {}, skillMap = {};
    cat.tools.forEach(function (t) { toolMap[t.id] = t.label; });
    cat.skills.forEach(function (s) { skillMap[s.id] = s.label; });

    var h = "";
    h += '<div class="cp-head"><span class="cp-av">' + esc((name[0] || "A").toUpperCase()) + "</span>" +
         '<div><h4 class="cp-name">' + esc(name) + '</h4><div class="cp-slug">' + esc(slug) + "</div></div></div>";

    var liveN = draft.connectors.filter(function (id) {
      var c = cat.connectors.filter(function (x) { return x.id === id; })[0];
      return c && connStatus(c) === "live";
    }).length;
    h += '<div class="cp-chips"><span class="cp-chip">7 fields</span>' +
         '<span class="cp-chip">' + draft.skills.length + " skills</span>" +
         '<span class="cp-chip">' + draft.tools.length + " tools</span>" +
         '<span class="cp-chip">' + liveN + " live connectors</span>" +
         '<span class="cp-chip">' + draft.files.length + " files</span></div>";

    h += '<div class="cp-sec"><h5>1 · Name</h5><p>' + esc(name) + "</p></div>";
    h += '<div class="cp-sec"><h5>2 · Description</h5><p>' + esc(desc || "—") + "</p></div>";
    h += '<div class="cp-sec"><h5>3 · Instruction</h5><div class="cp-inst">' + esc(instr || "—") + "</div></div>";

    h += '<div class="cp-sec"><h5>4 · Knowledge <span class="n">' + draft.knowledge.length + "</span></h5>";
    if (draft.knowledge.length) {
      h += '<div class="cp-list">';
      draft.knowledge.forEach(function (k) { h += '<span class="cp-item">' + esc(k) + "</span>"; });
      h += "</div>";
    } else h += '<p class="cp-note">No knowledge collections attached yet.</p>';
    if (draft.files.length) {
      h += '<div class="cp-list" style="margin-top:8px">';
      draft.files.forEach(function (f) {
        h += '<span class="cp-item">' + esc(f.name) + " · " + esc(extOf(f.name).toUpperCase()) + " · " + fmtSize(f.size) + "</span>";
      });
      h += "</div>";
    }
    h += "</div>";

    h += '<div class="cp-sec"><h5>5 · Tools <span class="n">' + draft.tools.length + "</span></h5>";
    if (draft.tools.length) {
      h += '<div class="cp-list">';
      draft.tools.forEach(function (id) { h += '<span class="cp-item">' + esc(toolMap[id] || id) + "</span>"; });
      h += "</div>";
    } else h += '<p class="cp-note">No tools granted.</p>';
    h += "</div>";

    h += '<div class="cp-sec"><h5>6 · Skills <span class="n">' + draft.skills.length + "</span></h5>";
    if (draft.skills.length) {
      h += '<div class="cp-list">';
      draft.skills.forEach(function (id) { h += '<span class="cp-item skill">' + esc(skillMap[id] || id) + "</span>"; });
      h += "</div>";
    } else h += '<p class="cp-note">No skills installed.</p>';
    h += "</div>";

    h += '<div class="cp-sec"><h5>7 · Connectors <span class="n">' + liveN + "/" + draft.connectors.length + " live</span></h5>";
    if (draft.connectors.length) {
      h += '<div class="cp-conn">';
      draft.connectors.forEach(function (id) {
        var c = cat.connectors.filter(function (x) { return x.id === id; })[0] || { id: id, label: id };
        var st = connStatus(c);
        h += '<div class="cp-connrow ' + st + '"><span class="dot"></span>' +
             '<span class="lbl">' + esc(c.label) + "</span>" +
             '<span class="st">' + st + "</span></div>";
      });
      h += "</div>";
      if (liveN < draft.connectors.length) {
        h += '<p class="cp-note">Only <strong>live</strong> means the provider is genuinely connected in this workspace, verified against <code>app_connections</code>. <strong>Available</strong> has a real provider integration you can connect with your own authorization; <strong>planned</strong> has no provider integration yet. The agent will not claim to have used any of them until they are live.</p>';
      }
    } else h += '<p class="cp-note">No connectors requested.</p>';
    h += "</div>";

    $("cardTitle").textContent = name;
    $("cardBody").innerHTML = h;
    $("cardModal").hidden = false;
  }

  /* ------------------------------------------------------------------ */
  /* save                                                                */
  /* ------------------------------------------------------------------ */
  function onSave(e) {
    e.preventDefault();
    var out = $("formMsg");
    var name = ($("fName").value || "").trim();
    var desc = ($("fDesc").value || "").trim();
    var instr = ($("fInstr").value || "").trim();
    var dept = ($("fDept").value || "").trim();
    var slug = ($("fSlug").value || "").trim();

    if (!name) return msg(out, "Field 1 — name is required.", "err");
    if (!desc) return msg(out, "Field 2 — description is required.", "err");
    if (instr.length < 10) return msg(out, "Field 3 — instruction must be at least 10 characters (production rule).", "err");
    if (!dept) return msg(out, "Department is required.", "err");
    if (!/^[a-z0-9-]+$/.test(slug)) return msg(out, "Slug must be lowercase letters, digits and hyphens only.", "err");
    if (uploading) return msg(out, "Wait for the file uploads to finish before saving.", "err");

    var toolMap = {}, skillMap = {};
    cat.tools.forEach(function (t) { toolMap[t.id] = t; });
    cat.skills.forEach(function (s) { skillMap[s.id] = s; });

    var config = {
      name: name,
      role: name,
      description: desc,
      instructions: instr,
      department: dept,
      driver: $("fDriver").value,
      model: "open-connect/auto",
      fallbackModel: "open-connect/auto-free",
      knowledge: draft.knowledge.slice(),
      knowledgeFiles: draft.files.filter(function (f) { return f.status === "uploaded"; }).map(function (f) {
        return { name: f.name, type: f.type || extOf(f.name).toUpperCase(), size: f.size, path: f.path, knowledgeId: f.knowledgeId || null };
      }),
      tools: draft.tools.map(function (id) {
        var t = toolMap[id] || {};
        return { id: id, label: t.label || id, description: t.description || "" };
      }),
      skillIds: draft.skills.slice(),
      skills: draft.skills.map(function (id) {
        var s = skillMap[id] || {};
        return { id: id, label: s.label || id };
      }),
      connectionIds: draft.connectors.slice(),
      connectors: draft.connectors.map(function (id) {
        var c = cat.connectors.filter(function (x) { return x.id === id; })[0] || { id: id, label: id };
        return { id: id, label: c.label || id, status: connStatus(c), provider: c.provider || "" };
      }),
      agencyAgentId: slug,
      agencyMode: $("fDriver").value === "human-led" ? "agentic" : "assistant",
      sourceResourceId: null
    };

    var btn = $("saveBtn");
    btn.disabled = true;
    msg(out, "Saving a new version to production…");
    setSave("Saving…");

    var args = {
      p_id: current ? current.id : null,
      p_project_id: null,
      p_slug: slug,
      p_lead: $("fDriver").value === "human-led",
      p_legacy_team_id: null,
      p_config: config,
      p_expected: current ? current.number : null
    };

    sb.rpc("save_workforce_agent", args).then(function (res) {
      btn.disabled = false;
      if (res.error) {
        msg(out, "Save failed: " + res.error.message, "err");
        setSave("Save failed", "err");
        return;
      }
      var d = res.data || {};
      // save_workforce_agent writes an immutable version but does NOT activate
      // it — without this second call the roster keeps serving the old config
      // and the toggles would appear not to persist.
      return sb.rpc("activate_workforce_agent", {
        p_id: d.agent_id,
        p_version_id: d.version_id,
        p_expected_active: current ? current.active_version_id : null
      }).then(function (ares) {
        if (ares.error) {
          msg(out, "Version " + d.number + " saved but not activated: " + ares.error.message, "err");
          setSave("Saved, not active", "err");
          return;
        }
        msg(out, "Saved and activated — agent " + String(d.agent_id || "").slice(0, 8) +
          "… now live at version " + d.number + ".", "ok");
        setSave("Live v" + d.number, "ok");
        dirty = false;
        loadRoster();
        setTimeout(function () {
          var row = roster.filter(function (r) { return r.id === d.agent_id; })[0];
          if (row) selectAgent(row);
        }, 700);
      });
    }).catch(function (err) {
      btn.disabled = false;
      msg(out, "Save failed: " + (err.message || err), "err");
      setSave("Save failed", "err");
    });
  }

  window.addEventListener("beforeunload", function (e) {
    if (dirty) { e.preventDefault(); e.returnValue = ""; }
  });

  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", boot);
  else boot();
})();
