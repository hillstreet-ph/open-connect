/* Open-Connect AI Factory — shared behaviour */
(function () {
  "use strict";
  document.documentElement.classList.add("js");

  /* ---- mobile nav ---- */
  var menuBtn = document.getElementById("menuBtn");
  var nav = document.getElementById("nav");
  if (menuBtn && nav) {
    menuBtn.addEventListener("click", function () {
      var open = nav.classList.toggle("open");
      menuBtn.setAttribute("aria-expanded", open ? "true" : "false");
    });
    nav.addEventListener("click", function (ev) {
      if (ev.target.tagName === "A") {
        nav.classList.remove("open");
        menuBtn.setAttribute("aria-expanded", "false");
      }
    });
  }

  /* ---- agent filter ---- */
  var agentSearch = document.getElementById("agentSearch");
  var agentCount = document.getElementById("agentCount");
  var noAgents = document.getElementById("noAgents");
  var teamList = document.getElementById("teamList");
  var teamChips = Array.prototype.slice.call(document.querySelectorAll("[data-filter]"));
  var activeTeam = "all";

  function applyAgents() {
    if (!teamList) return;
    var q = (agentSearch && agentSearch.value || "").trim().toLowerCase();
    var shown = 0;
    var groups = teamList.querySelectorAll(".team-group");
    Array.prototype.forEach.call(groups, function (group) {
      var gid = group.getAttribute("data-group");
      var teamOk = activeTeam === "all" || activeTeam === gid;
      var cards = group.querySelectorAll(".agent-card");
      var visibleInGroup = 0;
      Array.prototype.forEach.call(cards, function (card) {
        var name = card.getAttribute("data-name") || "";
        var ok = teamOk && (q === "" || name.indexOf(q) !== -1);
        card.style.display = ok ? "" : "none";
        if (ok) { visibleInGroup++; shown++; }
      });
      group.style.display = visibleInGroup > 0 ? "" : "none";
    });
    if (agentCount) agentCount.textContent = shown + (shown === 1 ? " agent" : " agents");
    if (noAgents) noAgents.style.display = shown === 0 ? "" : "none";
  }

  teamChips.forEach(function (chip) {
    chip.addEventListener("click", function () {
      activeTeam = chip.getAttribute("data-filter");
      teamChips.forEach(function (c) {
        c.setAttribute("aria-pressed", c === chip ? "true" : "false");
      });
      applyAgents();
    });
  });
  if (agentSearch) {
    var t1;
    agentSearch.addEventListener("input", function () {
      clearTimeout(t1);
      t1 = setTimeout(applyAgents, 120);
    });
  }

  /* ---- niche filter ---- */
  var nicheSearch = document.getElementById("nicheSearch");
  var nicheCount = document.getElementById("nicheCount");
  var noNiches = document.getElementById("noNiches");
  var nicheGrid = document.getElementById("nicheGrid");

  function applyNiches() {
    if (!nicheGrid) return;
    var q = (nicheSearch && nicheSearch.value || "").trim().toLowerCase();
    var shown = 0;
    var cards = nicheGrid.querySelectorAll(".niche-card");
    Array.prototype.forEach.call(cards, function (card) {
      var name = card.getAttribute("data-name") || "";
      var ok = q === "" || name.indexOf(q) !== -1;
      card.style.display = ok ? "" : "none";
      if (ok) shown++;
    });
    if (nicheCount) nicheCount.textContent = shown + (shown === 1 ? " niche" : " niches");
    if (noNiches) noNiches.style.display = shown === 0 ? "" : "none";
  }

  if (nicheSearch) {
    var t2;
    nicheSearch.addEventListener("input", function () {
      clearTimeout(t2);
      t2 = setTimeout(applyNiches, 120);
    });
  }

  /* ---- scroll reveal (content visible by default) ---- */
  var reduce = window.matchMedia && window.matchMedia("(prefers-reduced-motion: reduce)").matches;
  var items = Array.prototype.slice.call(document.querySelectorAll(".reveal"));
  if (!reduce && "IntersectionObserver" in window) {
    var io = new IntersectionObserver(function (entries) {
      entries.forEach(function (entry) {
        if (entry.isIntersecting) {
          entry.target.classList.add("in");
          io.unobserve(entry.target);
        }
      });
    }, { rootMargin: "0px 0px -8% 0px", threshold: 0.05 });
    items.forEach(function (el) { io.observe(el); });
    setTimeout(function () {
      items.forEach(function (el) { el.classList.add("in"); });
    }, 3000);
  } else {
    items.forEach(function (el) { el.classList.add("in"); });
  }
})();
